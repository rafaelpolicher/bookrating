
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
    
<?php if(auth()->guard()->check()): ?>
<div class="center">
    <h1>Ola <?php echo e(auth()->user()->firstname); ?> <?php echo e(auth()->user()->lastname); ?></h1>
    <p><?php echo e(auth()->user()->email); ?></p>
    <p>Voce é <?php echo e(auth()->user()->role); ?></p>
    <h4>Bio:</h4>
    <p><?php echo e(auth()->user()->bio); ?></p>
</div>
    
<?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bookrating\resources\views/site/profile.blade.php ENDPATH**/ ?>