
<?php $__env->startSection('title', 'Explore'); ?>
<?php $__env->startSection('content'); ?>


<div class="container">
    <h4 class="center">Todos os livros</h4>
    <?php echo $__env->make('custom.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('custom.sort', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <table>        
      <thead>
        <tr>
          <th>Imagem</th>
          <th>Título <i class="fas fa-sort"></i></th>
          <th>Autor <i class="fas fa-sort"></th>
          <th>Gênero <i class="fas fa-sort"></th>
          <th>Avaliação <i class="fas fa-sort"></i></th>
          <th>Última atualização <i class="fas fa-sort"></i></th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
              <?php if($book->image ==''): ?>
                <img class="responsive-img" src="<?php echo e(asset('images/cover.jpg')); ?> " style="width: 50px;" >                    
              <?php else: ?>
                <img src="<?php echo e(asset('storage/' . $book->image)); ?>" alt="" class="responsive-img" style="width: 50px;">
              <?php endif; ?>
            </td>
            <td><a href="<?php echo e(route('site.details', ['slug' => $book->slug])); ?>"><?php echo e($book->title); ?></a></td>
            <td><?php echo e($book->author); ?></td>
            <td><?php echo e($book->genre); ?></td>
            <td><?php echo e($book->editor_rating); ?> /10</td>
            <td><?php echo e($book->updated_at); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
      </tbody>
    </table> 
    <div class="center">
        <?php echo e($books->links('custom.pagination')); ?>

    </div>
</div>  
  <?php $__env->stopSection(); ?> 

<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bookrating\resources\views/site/allBooks.blade.php ENDPATH**/ ?>