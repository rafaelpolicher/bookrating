<?php if(session('error')): ?>
    <div class="error">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<?php if(session('sucesso')): ?>
    <div class="sucesso">
        <?php echo e(session('sucesso')); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="error">
        <?php echo e($error); ?><br>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>   <?php /**PATH C:\laragon\www\bookrating\resources\views/custom/msg.blade.php ENDPATH**/ ?>