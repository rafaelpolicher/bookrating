
<?php $__env->startSection('title', 'Add Book'); ?>
<?php $__env->startSection('content'); ?>

<div class="container center">
    <h3>Adicionar Livro</h3>
    <form method="POST" action="<?php echo e(route('books.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label class="left" for="title" >Título:</label>
        <input type="text" name="title" class="input-field" placeholder="Digite o título">

        <label class="left" for="author" >Autor:</label>
        <input type="text" name="author" class="input-field" placeholder="Digite o nome do autor">
        <label class="left" for="genre" >Gênero:</label>   
        <div class="input-field">
            <select name="genre">
                <option value="" selected disabled>Escolha o gênero</option>
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($genre); ?>"><?php echo e($genre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            </select>
        </div>

        <div class="file-field">
            <div class="btn">
                <span>Imagem</span>
                <input type="file" name="image">
                </div>
            <div class="file-path-wrapper">
                <input class="file-path validate input-field" type="text">
            </div>
        </div>

        <label class="left" for="editor_rating" >Nota(1 a 10): </label>
        <input placeholder="Digite a sua nota" type="number" name="editor_rating" id="rating" min="1" max="10" step="1">
            
        <label class="left" for="review" >Avaliação: </label>
        <textarea class="materialize-textarea" name="review" placeholder="O que você achou do livro" cols="30" rows="10"></textarea>

            
        <button class="btn green" type="submit">Adicionar Livro</button>
    </form>
</div>


    

<script>
    document.addEventListener('DOMContentLoaded', function() {
    var sel = document.querySelectorAll('select');
    var instances = M.FormSelect.init(sel);
    });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bookrating\resources\views/site/addBook.blade.php ENDPATH**/ ?>