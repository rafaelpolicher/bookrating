
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>

    

     <!-- Modal Structure -->
  <div id="modal" class="modal">
    <div class="modal-content">
      <h4>Atualize seu perfil</h4>
      <form action="" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
    
        <div class="input-field">
            <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
            <input type="text" id="firstname" name="firstname" value="<?php echo e($user->firstname); ?>" required>
            <label for="firstname">Nome</label>
        </div>
    
        <div class="input-field">
            <input type="text" id="lastname" name="lastname" value="<?php echo e($user->lastname); ?>" required>
            <label for="lastname">Sobrenome</label>
        </div>

        <div class="input-field">
            <input type="email" id="email" name="email" value="<?php echo e($user->email); ?>" readonly>
            <label for="email">Email</label>
        </div>
    
        <div class="file-field input-field">
            <div class="btn">
                <span>Foto de perfil</span>
                <input type="file" name="image">
            </div>
            <div class="file-path-wrapper">
                <input class="file-path validate" type="text">
            </div>
        </div>
    
        <div class="input-field">
            <textarea id="bio" name="bio"  class="materialize-textarea"><?php echo e($user->bio); ?></textarea>
            <label for="bio">Bio</label>
        </div>
        <button class="btn waves-effect waves-light" type="submit">Atualizar</button>
        

    </form>
    </div>
  </div>

</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bookrating\resources\views/user/show.blade.php ENDPATH**/ ?>