
<?php $__env->startSection('title', 'Register'); ?>
<?php $__env->startSection('content'); ?>

<div class="container center">
    <h3>Criar conta</h3>
    <form action="<?php echo e(route('login.create')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label class="left" for="firstname" >Nome:</label>
        <input type="text" name="firstname" class="input-field" placeholder="Digite seu primeiro nome">

        <label class="left" for="lastname" >Sobrenome:</label>
        <input type="text" name="lastname" class="input-field" placeholder="Digite seu sobrenome">

        <label class="left" for="email" >Email:</label>
        <input type="email" name="email" class="input-field" placeholder="Digite seu email">

        <label class="left" for="password" >Senha:</label>
        <input type="password" name="password" class="input-field" placeholder="Digite sua senha">
        <button class="btn green" type="submit">Registrar</button>
    </form>
    <a href="<?php echo e(route('login.login')); ?>">Já tenho uma conta</a>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bookrating\resources\views/login/register.blade.php ENDPATH**/ ?>