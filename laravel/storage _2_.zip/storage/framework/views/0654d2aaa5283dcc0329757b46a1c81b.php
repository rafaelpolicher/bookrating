
<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>

<?php if(auth()->guard()->check()): ?>
<section class="profile container">
    <div class="row ">
        <div class="col s12 m6 center">
            <?php if($user->image ==''): ?>
                <img class="responsive-img" src="<?php echo e(asset('images/user.png')); ?>" style="width: 300px;">                    
            <?php else: ?>
                <img src="<?php echo e(asset('storage/' . $user->image)); ?>" alt="" class="responsive-img" style="width: 300px;">
            <?php endif; ?>

        </div>

        <div class="col s12 m6 center">
            <h3>
                <span><?php echo e(auth()->user()->firstname); ?> <?php echo e(auth()->user()->lastname); ?></span>
            </h3>
        </div>

        <div class="col s12 m6">
            <span><?php echo e(auth()->user()->email); ?></span>
        </div>

        <div class="col s12 m6">
            <span><?php echo e(auth()->user()->role); ?></span>
        </div>


        <div class="">
            <p><?php echo e(auth()->user()->bio); ?></p>
        </div>
        <div class="center">
            <a class="waves-effect waves-light btn " href="<?php echo e(route('user.edit')); ?>">Atualizar perfil</a>
        </div>
        
    </div>    
    <?php if(auth()->user()->role != 'user'): ?>
        <div class="">
        <h4 class="center">Meus livros cadastrados</h4>
        <?php echo $__env->make('custom.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('custom.sort', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <table>   
            <thead>
              <tr>
                <th>Imagem</th>
                <th>Título <i class="fas fa-sort"></i></th>
                <th>Autor <i class="fas fa-sort"></th>
                <th>Gênero <i class="fas fa-sort"></th>
                <th>Avaliação <i class="fas fa-sort"></i></th>
                <th>Última atualização <i class="fas fa-sort"></i></th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($book->id_user === auth()->user()->id): ?>
                    <tr>
                        <td><?php if($book->image ==''): ?>
                            <img class="responsive-img" src="<?php echo e(asset('images/cover.jpg')); ?>"  style="width: 50px;">                    
                        <?php else: ?>
                            <img src="<?php echo e(asset('storage/' . $book->image)); ?>" alt="" class="responsive-img" style="width: 50px;">
                        <?php endif; ?>    
                        <td><a href="<?php echo e(route('site.details', ['slug' => $book->slug])); ?>"><?php echo e($book->title); ?></a></td>
                        <td><?php echo e($book->author); ?></td>
                        <td><?php echo e($book->genre); ?></td>
                        <td><?php echo e($book->editor_rating); ?> /10</td>
                        <td><?php echo e($book->updated_at); ?></td>
                    </tr>
                    </tr>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
            </tbody>
          </table>
        
    </div>
    <?php endif; ?>
    
        
</section>
 
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bookrating\resources\views/user/profile.blade.php ENDPATH**/ ?>