
<?php $__env->startSection('title', 'Edit'); ?>
<?php $__env->startSection('content'); ?>


<div class="container center">
    <h3>Editar usuário</h3>
    <form method="POST" action="<?php echo e(route('user.update')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label class="left" for="firtname" >Nome:</label>
        <input type="text" name="firstname" class="input-field" value="<?php echo e($user->firstname); ?>" placeholder="Digite seu nome">

        <label class="left" for="lastname" >Sobrenome:</label>
        <input type="text" name="lastname" class="input-field" value="<?php echo e($user->lastname); ?>" placeholder="Digite seu sobrenome">

        <label class="left" for="email" >Email</label>
        <input type="text" name="email" class="input-field" value="<?php echo e($user->email); ?>" readonly>

        <div class="file-field">
          <div class="btn">
            <span>Foto de perfil</span>
            <input type="file" name="image" value="<?php echo e($user->image); ?>">
          </div>
          <div class="file-path-wrapper">
            <input class="file-path validate input-field" type="text">
          </div>
        </div>
        
        <label class="left" for="bio" >Bio:</label>
        <textarea class="materialize-textarea" name="bio" placeholder="Conte mais sobre você" row="10"><?php echo e($user->bio); ?></textarea>

        
        <button class="btn green" type="submit">Atualizar perfil</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bookrating\resources\views/user/edit.blade.php ENDPATH**/ ?>