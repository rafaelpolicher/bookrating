
<?php $__env->startSection('title', 'Book'); ?>
<?php $__env->startSection('content'); ?>

<div class="details">
    <div class="row">
        <div class="col s12 m6 center">
            <?php if($book->image ==''): ?>
                <img class="responsive-img" src="<?php echo e(asset('images/cover.jpg')); ?>" >                    
            <?php else: ?>
                <img src="<?php echo e(asset('storage/' . $book->image)); ?>" alt="" class="responsive-img">
            <?php endif; ?>
        </div>

        <div class="col s12 m6 center">
            <h3>
                <span><?php echo e($book->title); ?></span>
            </h3>
        </div>

        <div class="col s12 m6">
            <span><?php echo e($book->genre); ?></span>
        </div>

        <div class="col s12 m6">
            <span><?php echo e($book->editor_rating); ?> /10</span>
        </div>

        <div class="col s12 m6">
            <h5><?php echo e($book->author); ?></h5><br>
        </div>

        <div class="">
            <p><?php echo e($book->review); ?></p>
        </div>
    </div>

    <div>
        <?php if(auth()->check() && $book->id_user === auth()->user()->id): ?>
            <a class="modal-trigger btn blue" href="#modal-update-<?php echo e($book->slug); ?>">Editar</a>
            <a class="modal-trigger btn red" href="#modal-delete-<?php echo e($book->slug); ?>">Excluir</a>
            
        <?php endif; ?>
    </div>

    <div class="row editor container">
        <div class="col s6 m3">
            <h4 class="center"><?php echo e($book->user->firstname); ?> <?php echo e($book->user->lastname); ?></h4>
        </div>
        <div class="col s6 m3">
            <img src="<?php echo e(asset('storage/' . $book->user->image)); ?>" alt=""  class="responsive-img circle">
        </div>
        <div class="">
            <p><?php echo e($book->user->bio); ?></p>
        </div> 
    </div>
    
<!--modal excluir-->
    <div id="modal-delete-<?php echo e($book->slug); ?>" class="modal">
        <div class="modal-content">
            <h4>Confirmação de exclusão</h4>
            <p>Deseja realmente excluir o livro <?php echo e($book->title); ?>?</p>
        </div>
        <div class="modal-footer">
            <form action="<?php echo e(route('book.delete', ['slug' => $book->slug])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn red">Excluir</button>
            </form>
        </div>
    </div>

    <!--modal editar-->
    <div id="modal-update-<?php echo e($book->slug); ?>" class="modal">
        <div class="modal-content">
        <!-- Conteúdo do modal -->
        <h4>Editar Livro</h4>
        <form action="<?php echo e(route('book.update', ['slug' => $book->slug])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <!-- Campos de edição do livro -->
            <label for="title">Título:</label>
            <input type="text" id="title" name="title" value="<?php echo e($book->title); ?>">
            
            <label for="author">Autor:</label>
            <input type="text" id="author" name="author" value="<?php echo e($book->author); ?>">

            <label for="editor_rating">Nota:</label>
            <input placeholder="Digite a sua nota" type="number" name="editor_rating" id="rating" min="1" max="10" step="1" value="<?php echo e($book->editor_rating); ?>">
                
            <label for="review">Avaliação:</label>
            <textarea class="materialize-textarea" name="review" placeholder="O que você achou do livro"><?php echo e($book->review); ?></textarea>
            
            <!-- Outros campos de edição -->
            
            <button class="btn green" type="submit btn green">Atualizar</button>
        </form>
        </div>
    </div>
  
</div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
      var modals = document.querySelectorAll('.modal');
      M.Modal.init(modals);
    });
  </script>
  
<?php $__env->stopSection(); ?> 


<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bookrating\resources\views/site/details.blade.php ENDPATH**/ ?>