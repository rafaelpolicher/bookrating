<?php if(session('error')): ?>
    <div class="error">
        <p class="center"><?php echo e(session('error')); ?></p>
    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="success">
        <p class="center"><?php echo e(session('success')); ?></p>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="error">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="center"><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>   <?php /**PATH C:\laragon\www\bookrating\resources\views/custom/messages.blade.php ENDPATH**/ ?>