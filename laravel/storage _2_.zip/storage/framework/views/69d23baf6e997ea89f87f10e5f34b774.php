
<?php $__env->startSection('title', 'Panel'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <h4 class="center">Usuarios cadastrados</h4>
        <?php echo $__env->make('custom.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('custom.sort', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <table>
            <thead>
              <tr>
                <th>Imagem</th>
                <th>Nome <i class="fas fa-sort"></i></th>
                <th>Sobrenome <i class="fas fa-sort"></th>
                <th>Email <i class="fas fa-sort"></th>
                <th>Função <i class="fas fa-sort"></i></th>
                <th>Usuário desde: <i class="fas fa-sort"></i></th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php if($user->image ==''): ?>
                            <img class="responsive-img" src="<?php echo e(asset('images/user.png')); ?>" style="width: 50px;">                    
                        <?php else: ?>
                            <img src="<?php echo e(asset('storage/' . $user->image)); ?>" alt="" class="responsive-img" style="width: 50px;">
                        <?php endif; ?></td>
                        <td><?php echo e($user->firstname); ?></td>
                        <td><?php echo e($user->lastname); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->role); ?></td>
                        <td><?php echo e($user->created_at); ?></td>
                        <?php if($user->role != "admin"): ?>
                            <td><a class="modal-trigger btn" href="#modal-updateRole-<?php echo e($user->id); ?>">Alterar função</a></td>
                        <?php endif; ?>
                    </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
            </tbody>
          </table>
          <div class="center">
            <?php echo e($users->links('custom.pagination')); ?>

          </div>
    </div>

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Modal para alterar a função do usuário -->
    <div id="modal-updateRole-<?php echo e($user->id); ?>" class="modal">
        <div class="modal-content">
            <h4>Alterar função do usuário - <?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h4>
            <form action="<?php echo e(route('user.updateRole', ['id' => $user->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="input-field">
                    <p>
                        <label>
                            <input type="radio" name="role" value="admin" />
                            <span>Admin</span>
                        </label>
                    </p>
                    <p>
                        <label>
                            <input type="radio" name="role" value="editor" />
                            <span>Editor</span>
                        </label>
                    </p>
                    <p>
                        <label>
                            <input type="radio" name="role" value="user" />
                            <span>User</span>
                        </label>
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="modal-close waves-effect waves-green btn-flat green">Salvar</button>
                    <a href="#!" class="modal-close waves-effect waves-red btn-flat red">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<script>
  document.addEventListener('DOMContentLoaded', function() {
    var modals = document.querySelectorAll('.modal');
    M.Modal.init(modals);
  });
</script>


 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bookrating\resources\views/admin/panel.blade.php ENDPATH**/ ?>