<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
</head>
<body>
  
<nav>
    <div class="nav-wrapper row">
        <div class="logo-container ">
            <a href="<?php echo e(route('site.home')); ?>" class="brand-logo">
                <img class="logo" src="<?php echo e(asset('images/logo.png')); ?>" alt="Book Rating logo">
            </a>
            <a href="#" data-target="mobile-menu" class="sidenav-trigger">
                <i class="material-icons">menu</i>
            </a>
        </div>

        <div class="link-container ">
            <ul class="right hide-on-med-and-down">
                <li><a href="<?php echo e(route('site.allBooks')); ?>"><i class="fa-solid fa-magnifying-glass"></i> Explorar</a></li>
                <li>
                    <a class="dropdown-trigger" href="#" data-target="dropdown-genre"><i class="fa-solid fa-book-open"></i> Gêneros<i class="material-icons right">arrow_drop_down</i></a>
                </li>

                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->role === 'admin'): ?>
                        <li><a href="<?php echo e(route('admin.panel')); ?>"><i class="fa-regular fa-hard-drive"></i> Painel</a></li> 
                    <?php endif; ?>
                    <?php if(auth()->user()->role != 'user'): ?>
                        <li><a href="<?php echo e(route('site.addBook')); ?>"><i class="fa-regular fa-square-plus"></i> Adicionar livro</a></li> 
                    <?php endif; ?>
                      
                    <li><a href="<?php echo e(route('user.profile')); ?>"><i class="fa-regular fa-user"></i>  <?php echo e(auth()->user()->firstname); ?></a></li>
                    <li><a href="<?php echo e(route('login.logout')); ?>"> <i class="fa-regular fa-circle-right"></i>  Sair</a></li>
                <?php else: ?>
                    <li><a href="<?php echo e(route('login.login')); ?>"> <i class="fa-regular fa-circle-right"></i> Entrar/ Registrar</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
  
<!-- Dropdown Structure -->
<?php
    $genres = ["Acadêmico", "Aventura", "Biografia", "Clássico", "Drama", "Ficção", "HQ", "Infantil", "Não-Ficção", "Novela", "Religioso", "Terror"];
?>

<ul id="dropdown-genre" class="dropdown-content">
    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route('books.genre', $genre)); ?>"><?php echo e($genre); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<ul class="sidenav" id="mobile-menu">
  <li><a href="<?php echo e(route('site.allBooks')); ?>"><i class="fa-solid fa-magnifying-glass"></i> Explorar</a></li>

  <?php if(auth()->guard()->check()): ?>
      <?php if(auth()->user()->role === 'admin'): ?>
          <li><a href="<?php echo e(route('admin.panel')); ?>"><i class="fa-regular fa-hard-drive"></i> Painel</a></li> 
      <?php endif; ?>
      <?php if(auth()->user()->role != 'user'): ?>
          <li><a href="<?php echo e(route('site.addBook')); ?>"><i class="fa-regular fa-square-plus"></i> Adicionar livro</a></li> 
      <?php endif; ?>
        
      <li><a href="<?php echo e(route('user.profile')); ?>"><i class="fa-regular fa-user"></i>  <?php echo e(auth()->user()->firstname); ?></a></li>
      <li><a href="<?php echo e(route('login.logout')); ?>"> <i class="fa-regular fa-circle-right"></i>  Sair</a></li>
  <?php else: ?>
      <li><a href="<?php echo e(route('login.login')); ?>"> <i class="fa-regular fa-circle-right"></i> Entrar/ Registrar</a></li>
  <?php endif; ?>

</ul>

<?php echo $__env->make('custom.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<footer class="row page-footer">
    <div class="col s4 center">
        <ul>
            <li><a href="<?php echo e(url('https://www.linkedin.com/in/rafael-policher-36651724a/')); ?>" target="_blank"><i class="fa-brands fa-linkedin-in"></i> Linkedin</a></li>
            <li><a href="<?php echo e(url('https://github.com/rafaelpolicher')); ?>" target="_blank"><i class="fa-brands fa-github"></i> Github</a></li>
            <li></li>
        </ul>
    </div>
  
    <div class="col s4 center">
        <p>BookRating &#169 2023</p>
    </div>

    <div class="col s4 center">
        <p>Desenvolvido por Rafael Policher</p>
    </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var elems = document.querySelectorAll('.sidenav');
        var instances = M.Sidenav.init(elems);

        var dropdowns = document.querySelectorAll('.dropdown-trigger');
        var options = {
            constrainWidth: false,
            coverTrigger: false // opcional, se você deseja que o dropdown seja aberto na posição do link
        };
        M.Dropdown.init(dropdowns, options);
    });
</script>
</body>
</html>
<?php /**PATH C:\laragon\www\bookrating\resources\views/site/layout.blade.php ENDPATH**/ ?>