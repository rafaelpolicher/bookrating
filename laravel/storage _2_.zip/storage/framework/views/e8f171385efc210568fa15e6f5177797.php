
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
<section id="home">
    <h3 class="center">
        <span>Ultimos adicionados</span>
    </h3>
    <div class="carousel">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="carousel-item" href="<?php echo e(route('site.details', $book->slug)); ?>"><span><?php echo e($book->editor_rating); ?> /10</span>
                <?php if($book->image ==''): ?>
                    <img class="responsive-img" src="<?php echo e(asset('images/cover.jpg')); ?>"  style="width: 200px;">                    
                <?php else: ?>
                    <img src="<?php echo e(asset('storage/' . $book->image)); ?>" alt="" class="responsive-img" style="width: 200px;">
                <?php endif; ?>    
                    <span><?php echo e($book->title); ?></span></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <h3 class="center">
        <span>Melhores</span>
    </h3>
    <div class="carousel">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->editor_rating=10): ?>
                <a class="carousel-item" href="<?php echo e(route('site.details', $book->slug)); ?>"><span><?php echo e($book->editor_rating); ?> /10</span><img src="<?php echo e(asset('storage/' . $book->image)); ?>"><p><?php echo e($book->title); ?></p></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <h3 class="center">
        <span>Biografia</span>
    </h3>
    <div class="carousel">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->genre=="Biografia"): ?>
                <a class="carousel-item" href="<?php echo e(route('site.details', $book->slug)); ?>"><span><?php echo e($book->editor_rating); ?> /10</span><img src="<?php echo e(asset('storage/' . $book->image)); ?>"><p><?php echo e($book->title); ?></p></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <h3 class="center">
        <span>Ficção</span>
    </h3>
    <div class="carousel">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->genre=="Ficção"): ?>
                <a class="carousel-item" href="<?php echo e(route('site.details', $book->slug)); ?>"><span><?php echo e($book->editor_rating); ?> /10</span><img src="<?php echo e(asset('storage/' . $book->image)); ?>"><p><?php echo e($book->title); ?></p></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <h3 class="center">
        <span>Drama</span>
    </h3>
    <div class="carousel">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->genre=="Drama"): ?>
                <a class="carousel-item" href="<?php echo e(route('site.details', $book->slug)); ?>"><span><?php echo e($book->editor_rating); ?> /10</span><img src="<?php echo e(asset('storage/' . $book->image)); ?>"><p><?php echo e($book->title); ?></p></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <h3 class="center">
        <span>Novela</span>
    </h3>
    <div class="carousel">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->genre=="Novela"): ?>
                <a class="carousel-item" href="<?php echo e(route('site.details', $book->slug)); ?>"><span><?php echo e($book->editor_rating); ?> /10</span><img src="<?php echo e(asset('storage/' . $book->image)); ?>"><p><?php echo e($book->title); ?></p></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <h3 class="center">
        <span>HQ</span>
    </h3>
    <div class="carousel">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->genre=="HQ"): ?>
                <a class="carousel-item" href="<?php echo e(route('site.details', $book->slug)); ?>"><span><?php echo e($book->editor_rating); ?> /10</span><img src="<?php echo e(asset('storage/' . $book->image)); ?>"><p><?php echo e($book->title); ?></p></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <h3 class="center">
        <span>Infantil</span>
    </h3>
    <div class="carousel">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->genre=="Infantil"): ?>
                <a class="carousel-item" href="<?php echo e(route('site.details', $book->slug)); ?>"><span><?php echo e($book->editor_rating); ?> /10</span><img src="<?php echo e(asset('storage/' . $book->image)); ?>"><p><?php echo e($book->title); ?></p></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <h3 class="center">
        <span>Romance</span>
    </h3>
    <div class="carousel">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->genre=="Romance"): ?>
                <a class="carousel-item" href="<?php echo e(route('site.details', $book->slug)); ?>"><span><?php echo e($book->editor_rating); ?> /10</span><img src="<?php echo e(asset('storage/' . $book->image)); ?>"><p><?php echo e($book->title); ?></p></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <h3 class="center">
        <span>Terror</span>
    </h3>
    <div class="carousel">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->genre=="Terror"): ?>
                <a class="carousel-item" href="<?php echo e(route('site.details', $book->slug)); ?>"><span><?php echo e($book->editor_rating); ?> /10</span><img src="<?php echo e(asset('storage/' . $book->image)); ?>"><p><?php echo e($book->title); ?></p></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <h3 class="center">
        <span>Acadêmico</span>
    </h3>
    <div class="carousel">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->genre=="Acadêmico"): ?>
                <a class="carousel-item" href="<?php echo e(route('site.details', $book->slug)); ?>"><span><?php echo e($book->editor_rating); ?> /10</span><img src="<?php echo e(asset('storage/' . $book->image)); ?>"><p><?php echo e($book->title); ?></p></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <h3 class="center">
        <span>Religioso</span>
    </h3>
    <div class="carousel">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->genre=="Religioso"): ?>
                <a class="carousel-item" href="<?php echo e(route('site.details', $book->slug)); ?>"><span><?php echo e($book->editor_rating); ?> /10</span><img src="<?php echo e(asset('storage/' . $book->image)); ?>"><p><?php echo e($book->title); ?></p></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <h3 class="center">
        <span>Clássico</span>
    </h3>
    <div class="carousel ">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->genre=="Clássico"): ?>
                <a class="carousel-item" href="<?php echo e(route('site.details', $book->slug)); ?>"><span><?php echo e($book->editor_rating); ?> /10</span><img src="<?php echo e(asset('storage/' . $book->image)); ?>"><p><?php echo e($book->title); ?></p></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <h3 class="center">
        <span>Não-Ficção</span>
    </h3>
    <div class="carousel">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->genre=="Não-Ficção"): ?>
                <a class="carousel-item" href="<?php echo e(route('site.details', $book->slug)); ?>"><span><?php echo e($book->editor_rating); ?> /10</span><img src="<?php echo e(asset('storage/' . $book->image)); ?>"><p><?php echo e($book->title); ?></p></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>


<script>
    document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.carousel');
    var instances = M.Carousel.init(elems, {
      // specify options here
    });
  });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bookrating\resources\views/site/home.blade.php ENDPATH**/ ?>